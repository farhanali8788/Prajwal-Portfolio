# Prajwal Kokate — Cinematographer Portfolio

A dark, cinematic single-page portfolio built with **Vite + React + Tailwind CSS**,
animated with **Framer Motion** + **GSAP ScrollTrigger**, and scrolled with **Lenis**.
Icons via **React Icons**.

The design uses a viewfinder / aperture motif throughout — corner framing brackets,
an aperture-blade loader, film-slate "Roll 01 / 02…" section indices, REC + timecode
overlays — so it reads like the site of someone who lives behind the camera.

---

## Run it

You need **Node 18+**.

```bash
npm install
npm run dev      # start the dev server (http://localhost:5173)
npm run build    # production build → /dist
npm run preview  # preview the production build
```

---

## Make it yours

Almost everything lives in one file: **`src/data/content.js`**. Edit copy there and it
updates across the whole site — profile, nav, about, stats, experience, work, gallery,
skills, equipment, testimonials, socials.

**Photos** — three behind-the-scenes frames are in `public/assets/`
(`bts-1.jpg`, `bts-2.jpg`, `bts-3.jpg`). Replace them with your own (keep the names, or
update the paths in `content.js`). For best results use wide 16:9 images.

**Showreel video** — the hero "Watch Showreel" button opens a modal. Drop your reel at
`public/showreel.mp4` and set `profile.showreel = '/showreel.mp4'` in `content.js`.
You can also enable a looping background video in the hero — see the commented block in
`src/components/sections/Hero.jsx`.

**Featured work** — `works[]` in `content.js`. The categories are real; the client names
and cover images are placeholders. Swap `client`, `cover`, and `video` (a real `video`
path makes the card open a player instead of a still).

**Testimonials** — `testimonials[]` are clearly-marked **sample quotes** for layout.
Replace them with real client words before going live.

---

## One thing to confirm

The brief asked for **"5+ years"**; the CV says **3+ years**. I used *5+* per the brief.
If 3+ is accurate, change one line — `profile.yearsLabel` in `content.js`.

---

## Deploy

It's a static site, so anything works:

- **Vercel** — import the repo, framework preset *Vite*, deploy.
- **Netlify** — build command `npm run build`, publish directory `dist`.
- **GitHub Pages** — `npm run build`, then publish `dist/`.

---

## Notes

- Custom cursor only activates on fine-pointer (mouse) devices; touch devices keep the
  native experience.
- Every animation respects `prefers-reduced-motion` — motion is dialed back for users
  who ask the OS to reduce it.
- Images are lazy-loaded; sections animate in on scroll via Intersection Observer.

---

## Stack

React 18 · Vite 5 · Tailwind CSS 3 · Framer Motion 11 · GSAP 3 (ScrollTrigger) ·
Lenis 1 · React Icons 5
